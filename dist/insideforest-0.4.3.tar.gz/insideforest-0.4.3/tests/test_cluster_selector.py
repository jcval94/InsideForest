from __future__ import annotations

import os, sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import numpy as np
import pandas as pd
import pytest
from InsideForest.ab_testing import BenchmarkConfig, benchmark_select_clusters
from InsideForest.cluster_selector import MenuClusterSelector, select_clusters
from InsideForest.legacy_select_clusters import select_clusters_legacy


def ab_test_select_clusters(
    df_datos: pd.DataFrame,
    df_reglas: pd.DataFrame,
    *,
    keep_all_clusters: bool = True,
    fallback_cluster: float | None = None,
) -> bool:
    """Compare the vectorised implementation against the reference version."""

    nuevo = select_clusters(
        df_datos,
        df_reglas,
        keep_all_clusters=keep_all_clusters,
        fallback_cluster=fallback_cluster,
    )
    anterior = select_clusters_legacy(
        df_datos,
        df_reglas,
        keep_all_clusters=keep_all_clusters,
        fallback_cluster=fallback_cluster,
    )

    if not np.array_equal(nuevo[0], anterior[0]):
        return False

    if keep_all_clusters:
        return nuevo[1] == anterior[1] and nuevo[2] == anterior[2]

    return nuevo[1] is None and nuevo[2] is None and anterior[1] is None and anterior[2] is None


def test_fallback_cluster_assignment():
    df_datos = pd.DataFrame({'x': [0.5, 2.0]})
    cols = pd.MultiIndex.from_tuples([
        ('linf', 'x'),
        ('lsup', 'x'),
        ('metrics', 'ponderador'),
    ])
    df_reglas = pd.DataFrame([[0.0, 1.0, 1.0]], columns=cols)
    df_reglas['cluster'] = [1.0]

    clusters, clusters_all, ponderadores_all = select_clusters(
        df_datos, df_reglas, keep_all_clusters=True, fallback_cluster=99
    )

    assert clusters[0] == 1.0
    assert clusters[1] == 99
    assert clusters_all[1] == [99]
    assert ponderadores_all[1] == [0.0]


def test_missing_column_in_rule_raises_error():
    df_datos = pd.DataFrame({'x': [0.5]})
    cols = pd.MultiIndex.from_tuples([
        ('linf', 'y'),
        ('lsup', 'y'),
        ('metrics', 'ponderador'),
    ])
    df_reglas = pd.DataFrame([[0.0, 1.0, 1.0]], columns=cols)
    df_reglas['cluster'] = [1.0]

    with pytest.raises(KeyError) as excinfo:
        select_clusters(df_datos, df_reglas)
    assert 'y' in str(excinfo.value)


def test_select_clusters_matches_reference_ab():
    rng = np.random.default_rng(1234)
    columnas = list("abc")
    df_datos = pd.DataFrame(
        rng.uniform(0.0, 1.0, size=(200, len(columnas))), columns=columnas
    )

    reglas_rows = []
    clusters = []
    for idx in range(6):
        use_col = rng.random(len(columnas)) > 0.4
        if not use_col.any():
            use_col[0] = True

        linf = np.full(len(columnas), np.nan)
        lsup = np.full(len(columnas), np.nan)
        linf_vals = rng.uniform(0.0, 0.6, size=use_col.sum())
        lsup_vals = linf_vals + rng.uniform(0.05, 0.3, size=use_col.sum())
        lsup_vals = np.clip(lsup_vals, linf_vals, 1.0)

        linf[use_col] = linf_vals
        lsup[use_col] = lsup_vals

        ponderador = float(idx + 1)
        reglas_rows.append(list(linf) + list(lsup) + [ponderador])
        clusters.append(float(idx + 1))

    columnas_multi = [
        ("linf", col) for col in columnas
    ] + [
        ("lsup", col) for col in columnas
    ] + [
        ("metrics", "ponderador")
    ]
    df_reglas = pd.DataFrame(
        reglas_rows,
        columns=pd.MultiIndex.from_tuples(columnas_multi),
    )
    df_reglas["cluster"] = clusters

    with pytest.warns(UserWarning):
        assert ab_test_select_clusters(
            df_datos,
            df_reglas,
            keep_all_clusters=True,
        )

    assert ab_test_select_clusters(
        df_datos,
        df_reglas,
        keep_all_clusters=False,
        fallback_cluster=0.0,
    )


def test_benchmark_select_clusters_matches_reference(tmp_path):
    rng = np.random.default_rng(4321)
    columnas = list("wxyz")
    df_datos = pd.DataFrame(
        rng.uniform(0.0, 1.0, size=(100, len(columnas))), columns=columnas
    )

    reglas_rows = []
    clusters = []
    for idx in range(10):
        use_col = rng.random(len(columnas)) > 0.5
        if not use_col.any():
            use_col[idx % len(columnas)] = True

        linf = np.full(len(columnas), np.nan)
        lsup = np.full(len(columnas), np.nan)
        linf_vals = rng.uniform(0.0, 0.7, size=use_col.sum())
        lsup_vals = np.clip(linf_vals + rng.uniform(0.05, 0.4, size=use_col.sum()), 0.0, 1.0)

        linf[use_col] = linf_vals
        lsup[use_col] = lsup_vals

        ponderador = float(idx + 1)
        reglas_rows.append(list(linf) + list(lsup) + [ponderador])
        clusters.append(float(idx % 3))

    columnas_multi = [
        ("linf", col) for col in columnas
    ] + [
        ("lsup", col) for col in columnas
    ] + [
        ("metrics", "ponderador")
    ]
    df_reglas = pd.DataFrame(
        reglas_rows,
        columns=pd.MultiIndex.from_tuples(columnas_multi),
    )
    df_reglas["cluster"] = clusters

    config = BenchmarkConfig(runs=2, keep_all_clusters=True, fallback_cluster=None)
    df_results = benchmark_select_clusters(df_datos, df_reglas, config=config)

    assert (df_results["results_match"] == True).all()
    assert set(df_results.columns) == {
        "run",
        "vectorized_seconds",
        "legacy_seconds",
        "speedup",
        "results_match",
        "faster",
    }

    output_path = tmp_path / "benchmark.csv"
    df_results.to_csv(output_path, index=False)
    loaded = pd.read_csv(output_path)
    assert (loaded["results_match"] == True).all()


def test_menu_cluster_selector_catalog_makes_progress_with_negative_scores():
    records = [[3.0], [0.0, 2.0, 3.0], [0.0, 2.0], [0.0, 1.0, 2.0]]
    y = [0, 1, 0, 1]

    selector = MenuClusterSelector(seed=42)
    selector.fit(records, y)
    labels = selector.predict(records, n_clusters=2)

    assert len(labels) == len(records)
    assert all(label in row for label, row in zip(labels, records))


@pytest.mark.parametrize("n_rows,n_rules,batch_size", [(30, 8, 7), (300, 40, 64)])
def test_select_clusters_chunked_matches_full_matrix(n_rows, n_rules, batch_size):
    rng = np.random.default_rng(9876 + n_rows + n_rules)
    columnas = list("abcd")
    df_datos = pd.DataFrame(
        rng.uniform(0.0, 1.0, size=(n_rows, len(columnas))), columns=columnas
    )

    reglas_rows = []
    clusters = []
    for idx in range(n_rules):
        use_col = rng.random(len(columnas)) > 0.3
        if not use_col.any():
            use_col[rng.integers(0, len(columnas))] = True

        linf = np.full(len(columnas), np.nan)
        lsup = np.full(len(columnas), np.nan)
        linf_vals = rng.uniform(0.0, 0.7, size=use_col.sum())
        lsup_vals = np.clip(linf_vals + rng.uniform(0.01, 0.3, size=use_col.sum()), 0.0, 1.0)

        linf[use_col] = linf_vals
        lsup[use_col] = lsup_vals

        reglas_rows.append(list(linf) + list(lsup) + [float(idx + 1)])
        clusters.append(float((idx % 5) + 1))

    columnas_multi = [("linf", col) for col in columnas] + [("lsup", col) for col in columnas] + [("metrics", "ponderador")]
    df_reglas = pd.DataFrame(reglas_rows, columns=pd.MultiIndex.from_tuples(columnas_multi))
    df_reglas["cluster"] = clusters

    chunked = select_clusters(
        df_datos,
        df_reglas,
        keep_all_clusters=True,
        fallback_cluster=0.0,
        batch_size=batch_size,
    )
    full_matrix = select_clusters(
        df_datos,
        df_reglas,
        keep_all_clusters=True,
        fallback_cluster=0.0,
        batch_size=None,
    )

    assert np.array_equal(chunked[0], full_matrix[0])
    assert chunked[1] == full_matrix[1]
    assert chunked[2] == full_matrix[2]
